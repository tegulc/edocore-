import type { LucideIcon } from 'lucide-react';
import {
  LayoutDashboard, Users, GraduationCap, BookOpen, CalendarClock,
  ClipboardCheck, Wallet, Library, MessageSquare, Bell, ShieldCheck, Building2,
} from 'lucide-react';
import type { RoleCode } from '@/types/auth';

export interface ElementNav {
  libelle: string;
  chemin: string;
  icone: LucideIcon;
  /** Roles autorises a voir cet element. Vide = visible par tous les roles connectes. */
  roles?: RoleCode[];
}

/**
 * Source unique de verite pour la barre laterale. Chaque module ajoute son
 * entree ici au fur et a mesure de sa livraison (Phase 1, 2, 3...).
 */
export const NAVIGATION: ElementNav[] = [
  { libelle: 'Tableau de bord', chemin: '/', icone: LayoutDashboard },
  { libelle: 'Etablissement', chemin: '/etablissement', icone: Building2, roles: ['ADMIN', 'DIRECTEUR'] },
  { libelle: 'Utilisateurs', chemin: '/utilisateurs', icone: Users, roles: ['ADMIN', 'DIRECTEUR'] },
  { libelle: 'Eleves', chemin: '/eleves', icone: GraduationCap },
  { libelle: 'Parents', chemin: '/parents', icone: Users, roles: ['ADMIN', 'DIRECTEUR', 'CENSEUR', 'SECRETAIRE'] },
  { libelle: 'Enseignants', chemin: '/enseignants', icone: Users, roles: ['ADMIN', 'DIRECTEUR', 'CENSEUR'] },
  { libelle: 'Classes & matieres', chemin: '/classes', icone: BookOpen },
  { libelle: 'Emploi du temps', chemin: '/emploi-du-temps', icone: CalendarClock },
  { libelle: 'Presences', chemin: '/presences', icone: ClipboardCheck },
  { libelle: 'Paiements', chemin: '/paiements', icone: Wallet },
  { libelle: 'Bibliotheque', chemin: '/bibliotheque', icone: Library },
  { libelle: 'Messagerie', chemin: '/messagerie', icone: MessageSquare },
  { libelle: 'Notifications', chemin: '/notifications', icone: Bell },
  { libelle: 'Securite & audit', chemin: '/securite', icone: ShieldCheck, roles: ['ADMIN'] },
];
