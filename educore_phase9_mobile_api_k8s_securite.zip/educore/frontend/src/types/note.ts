export interface EvaluationProfil {
  id: number;
  classeMatiereId: number;
  typeEvaluationCode: string;
  periodeId: number;
  titre: string;
  dateEvaluation: string;
  bareme: number;
  statut: 'planifiee' | 'saisie' | 'validee' | 'publiee';
}

export interface NoteProfil {
  id: number;
  evaluationId: number;
  eleveId: number;
  eleveNom: string;
  valeur: number | null;
  absent: boolean;
  observation: string | null;
  valide: boolean;
}

export interface MoyenneGeneraleProfil {
  eleveId: number;
  eleveNom: string;
  moyenneGenerale: number | null;
  rangClasse: number | null;
  decision: string | null;
}

export interface BulletinProfil {
  id: number;
  eleveId: number;
  eleveNom: string;
  classeId: number;
  periodeId: number;
  moyenneGenerale: number | null;
  rang: number | null;
  appreciationGenerale: string | null;
  decisionConseil: string | null;
  nombreAbsences: number;
  statut: 'brouillon' | 'valide' | 'publie';
  moyennesParMatiere: { classeMatiereId: number; matiereLibelle: string; moyenne: number | null; rangMatiere: number | null }[];
}
