import { useEffect, useState } from 'react';
import { CalendarClock } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { classeApi } from '@/lib/classeApi';
import { emploiDuTempsApi } from '@/lib/emploiDuTempsApi';
import { JOURS_SEMAINE, type SeanceProfil } from '@/types/emploiDuTemps';
import type { ClasseProfil } from '@/types/classe';

export default function PageEmploiDuTemps() {
  const [classes, setClasses] = useState<ClasseProfil[]>([]);
  const [classeId, setClasseId] = useState<string>('');
  const [seances, setSeances] = useState<SeanceProfil[]>([]);
  const [chargement, setChargement] = useState(true);

  useEffect(() => { classeApi.lister().then(({ data }) => { setClasses(data); setChargement(false); }); }, []);

  useEffect(() => {
    if (classeId) emploiDuTempsApi.parClasse(Number(classeId)).then(({ data }) => setSeances(data));
  }, [classeId]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold">Emploi du temps</h1>
        <p className="text-sm text-ink-400 mt-1">Grille hebdomadaire par classe, année scolaire active.</p>
      </div>

      <Card>
        <label className="block max-w-xs">
          <span className="text-sm font-medium">Classe</span>
          <select value={classeId} onChange={(e) => setClasseId(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-ink-100 dark:border-white/10 bg-white dark:bg-surface-darkAlt px-3.5 py-2.5 text-sm">
            <option value="">{chargement ? 'Chargement…' : 'Choisir une classe…'}</option>
            {classes.map((c) => <option key={c.id} value={c.id}>{c.libelle}</option>)}
          </select>
        </label>
      </Card>

      {classeId && (
        <Card className="p-0 overflow-hidden">
          {seances.length === 0 ? (
            <p className="p-6 text-sm text-ink-400 text-center">Aucune séance planifiée pour cette classe.</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-ink-50 dark:bg-white/5 text-left text-ink-400">
                <tr>
                  <th className="px-4 py-3 font-medium">Jour</th>
                  <th className="px-4 py-3 font-medium">Créneau</th>
                  <th className="px-4 py-3 font-medium">Matière</th>
                  <th className="px-4 py-3 font-medium hidden sm:table-cell">Enseignant</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100 dark:divide-white/10">
                {[...seances].sort((a, b) => a.jourSemaine - b.jourSemaine).map((s) => (
                  <tr key={s.id}>
                    <td className="px-4 py-3 font-medium">{JOURS_SEMAINE[s.jourSemaine]}</td>
                    <td className="px-4 py-3 text-ink-400 flex items-center gap-1.5">
                      <CalendarClock size={14} /> {s.creneauLibelle ?? `#${s.creneauId}`}
                    </td>
                    <td className="px-4 py-3">{s.matiereLibelle}</td>
                    <td className="px-4 py-3 text-ink-400 hidden sm:table-cell">{s.enseignantNom}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}
    </div>
  );
}
