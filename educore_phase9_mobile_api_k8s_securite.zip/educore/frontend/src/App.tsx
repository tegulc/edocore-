import { useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import { AppShell } from '@/components/layout/AppShell';
import { RouteProtegee } from '@/components/layout/RouteProtegee';
import PageConnexion from '@/pages/auth/PageConnexion';
import PageInscription from '@/pages/auth/PageInscription';
import PageTableauDeBord from '@/pages/dashboard/PageTableauDeBord';
import PageProfil from '@/pages/dashboard/PageProfil';
import PageUtilisateurs from '@/pages/dashboard/PageUtilisateurs';
import PageEtablissement from '@/pages/dashboard/PageEtablissement';
import PageClasses from '@/pages/dashboard/PageClasses';
import PageEnseignants from '@/pages/dashboard/PageEnseignants';
import PageEleves from '@/pages/dashboard/PageEleves';
import PageParents from '@/pages/dashboard/PageParents';
import PageEmploiDuTemps from '@/pages/dashboard/PageEmploiDuTemps';
import PagePresences from '@/pages/dashboard/PagePresences';
import { useAuth } from '@/hooks/useAuth';
import { authApi } from '@/lib/authApi';

/**
 * Arborescence de routage. Chaque module ajoutera ses propres routes
 * enfants sous <AppShell/> (ex: /eleves, /paiements, ...) au fil des phases.
 *
 * Au premier chargement, si un refresh token existe deja (session precedente),
 * on tente une reconnexion silencieuse avant d'afficher quoi que ce soit
 * derriere une route protegee (evite un flash de redirection vers /connexion).
 */
export default function App() {
  const { refreshToken, connecter, deconnecter, terminerHydratation } = useAuth();

  useEffect(() => {
    async function hydrater() {
      if (!refreshToken) {
        terminerHydratation();
        return;
      }
      try {
        const { data } = await authApi.refresh(refreshToken);
        if (data.jeton && data.jetonRafraichissement && data.utilisateur) {
          connecter(data.utilisateur, data.jeton, data.jetonRafraichissement);
        } else {
          deconnecter();
        }
      } catch {
        deconnecter();
      } finally {
        terminerHydratation();
      }
    }
    hydrater();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Routes>
      <Route path="/connexion" element={<PageConnexion />} />
      <Route path="/inscription" element={<PageInscription />} />

      <Route element={<RouteProtegee><AppShell /></RouteProtegee>}>
        <Route path="/" element={<PageTableauDeBord />} />
        <Route path="/profil" element={<PageProfil />} />
        <Route
          path="/etablissement"
          element={
            <RouteProtegee rolesAutorises={['ADMIN', 'DIRECTEUR']}>
              <PageEtablissement />
            </RouteProtegee>
          }
        />
        <Route
          path="/utilisateurs"
          element={
            <RouteProtegee rolesAutorises={['ADMIN', 'DIRECTEUR']}>
              <PageUtilisateurs />
            </RouteProtegee>
          }
        />
        <Route path="/classes" element={<PageClasses />} />
        <Route path="/enseignants" element={<PageEnseignants />} />
        <Route path="/eleves" element={<PageEleves />} />
        <Route path="/parents" element={<PageParents />} />
        <Route path="/emploi-du-temps" element={<PageEmploiDuTemps />} />
        <Route path="/presences" element={<PagePresences />} />
      </Route>
    </Routes>
  );
}
