import { create } from 'zustand';
import type { UtilisateurProfil } from '@/types/auth';

interface AuthState {
  utilisateur: UtilisateurProfil | null;
  accessToken: string | null;
  refreshToken: string | null;
  hydrate: boolean; // true tant que la tentative de reconnexion silencieuse au chargement n'est pas terminee
  connecter: (utilisateur: UtilisateurProfil, accessToken: string, refreshToken: string) => void;
  definirAccessToken: (accessToken: string) => void;
  deconnecter: () => void;
  terminerHydratation: () => void;
}

const CLE_REFRESH = 'educore-refresh-token';

/**
 * Etat d'authentification global (Phase 1).
 * Le refresh token est persiste en localStorage pour permettre une reconnexion
 * silencieuse au rechargement de page. Amelioration de securite prevue en
 * production : refresh token en cookie httpOnly plutot qu'accessible en JS.
 */
export const useAuth = create<AuthState>((set) => ({
  utilisateur: null,
  accessToken: null,
  refreshToken: localStorage.getItem(CLE_REFRESH),
  hydrate: false,
  connecter: (utilisateur, accessToken, refreshToken) => {
    localStorage.setItem(CLE_REFRESH, refreshToken);
    set({ utilisateur, accessToken, refreshToken });
  },
  definirAccessToken: (accessToken) => set({ accessToken }),
  deconnecter: () => {
    localStorage.removeItem(CLE_REFRESH);
    set({ utilisateur: null, accessToken: null, refreshToken: null });
  },
  terminerHydratation: () => set({ hydrate: true }),
}));
