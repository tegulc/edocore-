package com.educore.modules.note.dto;

import java.math.BigDecimal;
import java.util.List;

public class BulletinDto {
    public record Profil(Long id, Long eleveId, String eleveNom, Long classeId, Long periodeId,
                          BigDecimal moyenneGenerale, Integer rang, String appreciationGenerale,
                          String decisionConseil, Integer nombreAbsences, String statut,
                          List<MoyenneDto.Matiere> moyennesParMatiere) {}
}
