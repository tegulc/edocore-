package com.educore.modules.classe.dto;

import jakarta.validation.constraints.NotBlank;

public class SerieDto {
    public record Creation(@NotBlank String code, @NotBlank String libelle) {}
    public record Profil(Long id, String code, String libelle) {}
}
