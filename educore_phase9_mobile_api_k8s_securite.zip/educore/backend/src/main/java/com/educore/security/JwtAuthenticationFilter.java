package com.educore.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Extrait le JWT de l'en-tete Authorization, le valide, puis peuple le
 * SecurityContext avec un {@link UtilisateurPrincipal} (utilisateur + tenant + roles).
 *
 * Support multi-role : une GrantedAuthority ROLE_xxx est creee pour CHAQUE
 * role attribue a l'utilisateur (claim "roles" du JWT), afin que
 * @PreAuthorize("hasRole('X')") ou hasAnyRole(...) fonctionnent correctement
 * quel que soit le role concerne, pas seulement le role principal.
 *
 * Regle de securite : seul un jeton de type "access" ou "api_client" peut
 * authentifier une requete API. Un refresh token ou un jeton transitoire
 * "deux_fa_pending" presente ici est ignore (la requete reste anonyme, donc
 * rejetee en 401 par les regles d'autorisation) : sans cette verification,
 * un refresh token intercepte pourrait servir directement d'access token.
 * Les jetons "api_client" (Phase 9, integrations partenaires) recoivent un
 * principal distinct ({@link ApiClientPrincipal}) et la seule autorite
 * ROLE_API_CLIENT - jamais un role metier, jamais confondu avec un utilisateur reel.
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;

    public JwtAuthenticationFilter(JwtService jwtService) {
        this.jwtService = jwtService;
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {

        String enTete = request.getHeader("Authorization");
        if (enTete != null && enTete.startsWith("Bearer ")) {
            String token = enTete.substring(7);
            String type = jwtService.estValide(token) ? jwtService.extraireType(token) : null;

            if ("access".equals(type)) {
                Claims claims = extraireClaims(token);
                Long utilisateurId = Long.valueOf(claims.getSubject());
                Long etablissementId = Long.valueOf(String.valueOf(claims.get("etablissementId")));
                String rolePrincipal = String.valueOf(claims.get("role"));
                List<String> rolesBrut = claims.get("roles", List.class);
                Set<String> roles = rolesBrut != null ? Set.copyOf(rolesBrut) : Set.of(rolePrincipal);

                UtilisateurPrincipal principal = new UtilisateurPrincipal(utilisateurId, etablissementId, rolePrincipal, roles);

                List<GrantedAuthority> autorites = roles.stream()
                        .map(r -> (GrantedAuthority) new SimpleGrantedAuthority("ROLE_" + r))
                        .collect(Collectors.toList());

                SecurityContextHolder.getContext().setAuthentication(
                        new UsernamePasswordAuthenticationToken(principal, null, autorites));
                TenantContext.definir(etablissementId);

            } else if ("api_client".equals(type)) {
                Claims claims = extraireClaims(token);
                String clientId = claims.getSubject();
                Long etablissementId = Long.valueOf(String.valueOf(claims.get("etablissementId")));

                ApiClientPrincipal principal = new ApiClientPrincipal(clientId, etablissementId);
                SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(
                        principal, null, List.of(new SimpleGrantedAuthority("ROLE_API_CLIENT"))));
                TenantContext.definir(etablissementId);
            }
        }

        try {
            chain.doFilter(request, response);
        } finally {
            TenantContext.effacer(); // evite toute fuite de contexte entre requetes (pool de threads)
        }
    }

    private Claims extraireClaims(String token) {
        // Reutilise la meme cle que JwtService : la validation d'integrite a deja ete faite dans estValide().
        return Jwts.parser().build().parseSignedClaims(token).getPayload();
    }
}
