package com.educore.modules.note.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.Instant;

@Getter @Setter
@Entity
@Table(name = "bulletins", uniqueConstraints = @UniqueConstraint(columnNames = {"eleve_id", "periode_id"}))
public class Bulletin {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "eleve_id", nullable = false) private Long eleveId;
    @Column(name = "classe_id", nullable = false) private Long classeId;
    @Column(name = "periode_id", nullable = false) private Long periodeId;
    @Column(name = "moyenne_generale") private BigDecimal moyenneGenerale;
    private Integer rang;
    @Column(name = "appreciation_generale") private String appreciationGenerale;
    @Column(name = "decision_conseil") private String decisionConseil;
    @Column(name = "nombre_absences") private Integer nombreAbsences = 0;
    @Column(name = "fichier_pdf_url") private String fichierPdfUrl;
    private String statut = "brouillon"; // brouillon, valide, publie
    @Column(name = "genere_le") private Instant genereLe;
}
