package com.educore.modules.note.dto;

import java.math.BigDecimal;

public class MoyenneDto {
    public record Matiere(Long classeMatiereId, String matiereLibelle, BigDecimal moyenne, Integer rangMatiere) {}
    public record Generale(Long eleveId, String eleveNom, BigDecimal moyenneGenerale, Integer rangClasse, String decision) {}
}
