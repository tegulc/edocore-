package com.educore.ia.risque.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import java.time.LocalDate;

/**
 * Requetes de lecture seule sur des tables geree par educore-backend
 * (presences_eleves, sanctions), necessaires au calcul du score de risque.
 * Pas d'entite JPA complete ici : ces deux comptages suffisent, inutile
 * d'importer tout le modele Presence/Discipline dans ce service.
 */
public interface IndicateursRisqueRepository extends Repository<Object, Long> {

    @Query(value = "SELECT COUNT(*) FROM presences_eleves WHERE eleve_id = :eleveId AND type_presence = 'absent' " +
            "AND justifie = false AND date_jour BETWEEN :debut AND :fin", nativeQuery = true)
    long compterAbsencesNonJustifiees(Long eleveId, LocalDate debut, LocalDate fin);

    @Query(value = "SELECT COUNT(*) FROM sanctions WHERE eleve_id = :eleveId", nativeQuery = true)
    long compterSanctions(Long eleveId);
}
